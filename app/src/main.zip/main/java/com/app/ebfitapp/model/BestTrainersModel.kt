package com.app.ebfitapp.model

data class BestTrainersModel(val profileImageURL: String, val username: String, val specialization: String)