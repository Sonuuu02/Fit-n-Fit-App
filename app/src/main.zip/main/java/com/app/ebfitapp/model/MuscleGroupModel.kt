package com.app.ebfitapp.model

import java.io.Serializable

data class MuscleGroupModel(val muscleName: String, val muscleImageURL: String) : Serializable