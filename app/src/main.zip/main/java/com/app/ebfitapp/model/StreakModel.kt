package com.app.ebfitapp.model

data class StreakModel(var count: Int, var date: String, val email: String)