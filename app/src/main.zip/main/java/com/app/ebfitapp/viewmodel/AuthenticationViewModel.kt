package com.app.ebfitapp.viewmodel

import androidx.lifecycle.ViewModel

class AuthenticationViewModel : ViewModel() {

}