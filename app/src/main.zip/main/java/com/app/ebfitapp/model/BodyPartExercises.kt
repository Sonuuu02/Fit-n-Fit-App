package com.app.ebfitapp.model


import com.google.gson.annotations.SerializedName

class BodyPartExercises : ArrayList<BodyPartExercisesItem>()